package utils;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;

public class JavaScriptMethods {
    static JavascriptExecutor jsEx = (JavascriptExecutor) WebDriverSingleton.getWebDriver();

    public static void elementsHighlighter(WebElement element) {
        jsEx.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: 2px solid red;')", element);
//        Thread.sleep(1000);
//        jsEx.executeScript("arguments[0].style.border=''", element, "");
//        Thread.sleep(1000);
//        jsEx.executeScript("arguments[0].style.background=''", footerSolutions, "");
//        System.out.println(footerSolutions.isSelected());
    }

    public static void pageScroller() throws InterruptedException {
        jsEx.executeScript("window.scrollBy(0, 1500)", "");
        Thread.sleep(1000);

        jsEx.executeScript("window.scrollTo(0, document.body.scrollHeight)");
        Thread.sleep(1000);

        jsEx.executeScript("window.scrollTo(document.body.scrollHeight, 0)");
        Thread.sleep(1000);

//        jsEx.executeScript("window.scrollTo(0, 0)");
//        Thread.sleep(1000);
    }

    public static void scrollToElement(WebElement element) throws InterruptedException {
        jsEx.executeScript("arguments[0].scrollIntoView();", element);
        Thread.sleep(1000);
    }
}
