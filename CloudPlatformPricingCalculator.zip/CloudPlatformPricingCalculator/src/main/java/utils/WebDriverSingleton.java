package utils;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;

import java.time.Duration;

public class WebDriverSingleton {
    private static WebDriver driver;
    private static final String BROWSER_TYPE = "Chrome";
    private static final String CHROME_DRIVER_PATH = "Path_to_Chrome_driver";
    private static final String FIREFOX_DRIVER_PATH = "Path_to_Firefox_driver";
    private static final int WAIT_SECONDS = 10;
    private static ChromeOptions chromeOptions = new ChromeOptions();   //String added according Chrome webdriver 111.0.5563.64 version running solution

    private WebDriverSingleton() {
    }

    public static WebDriver getWebDriver() {
        if (driver == null) {
            driver = createDriver();

            driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(WAIT_SECONDS));
            driver.manage().timeouts().pageLoadTimeout(Duration.ofSeconds(WAIT_SECONDS));
            driver.manage().timeouts().scriptTimeout(Duration.ofSeconds(WAIT_SECONDS));
            driver.manage().window().maximize();
        }
        return driver;
    }

    private static WebDriver createDriver() {
        switch (BROWSER_TYPE) {
            case "Chrome":
            case "CHROME":
            case "chrome": {
                chromeOptions.addArguments("--remote-allow-origins=*");     //String added according Chrome webdriver 111.0.5563.64 version running solution
                System.setProperty("webdriver.chrome.driver", CHROME_DRIVER_PATH + "chromedriver.exe");
                driver = new ChromeDriver(chromeOptions);       //Value in brackets added according Chrome webdriver 111.0.5563.64 version running solution
                break;

            }
            case "Firefox":
            case "FIREFOX":
            case "firefox": {
                System.setProperty("webdriver.firefox.driver", FIREFOX_DRIVER_PATH + "geckodriver.exe");
                driver = new FirefoxDriver();
                break;
            }
            default:
                throw new IllegalArgumentException("Value of browser type " + BROWSER_TYPE + " is incorrect");
        }
        return driver;
    }

    public static void quitDriver() {
        if (driver != null) {
            driver.quit();
            driver = null;
        }
    }

}
