package pageObjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;
import utils.WebDriverSingleton;

import java.time.Duration;

public abstract class PageObjectBasics {
    protected static WebDriver driver;
    protected static WebDriverWait explicitWait;

    protected PageObjectBasics(WebDriver driver) {
        if (this.driver == null)
            this.driver = driver;
        PageFactory.initElements(driver, this);
        explicitWait = new WebDriverWait(driver, Duration.ofSeconds(15));
    }


}
