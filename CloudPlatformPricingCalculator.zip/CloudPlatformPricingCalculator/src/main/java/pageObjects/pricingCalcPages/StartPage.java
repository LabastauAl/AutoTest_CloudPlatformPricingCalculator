package pageObjects.pricingCalcPages;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import pageObjects.PageObjectBasics;


public class StartPage extends PageObjectBasics {

    @FindBy(xpath = "//div[@class='devsite-searchbox']")
    private WebElement searchButton;
    @FindBy(xpath = "//div[@class='devsite-searchbox']/input")
    private WebElement searchInputField;

    public StartPage(WebDriver driver) {
        super(driver);
    }

    public void searchingOfInfo(String infoString) {
        searchButton.click();
        searchInputField.sendKeys(infoString);
        searchInputField.sendKeys(Keys.ENTER);
    }
}
