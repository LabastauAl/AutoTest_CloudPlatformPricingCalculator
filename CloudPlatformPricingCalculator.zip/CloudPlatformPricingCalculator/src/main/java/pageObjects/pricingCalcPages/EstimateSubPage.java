package pageObjects.pricingCalcPages;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import pageObjects.PageObjectBasics;
import utils.JavaScriptMethods;

public class EstimateSubPage extends PageObjectBasics {
    public EstimateSubPage(WebDriver driver) {
        super(driver);
    }

    @FindBy(xpath = "//md-card-content[@id='resultBlock']//div[contains(text(), 'Provisioning model:')]")
    private WebElement resultBlock_provisioningModel;

    @FindBy(xpath = "//md-card-content[@id='resultBlock']//div[contains(text(), 'Instance type:')]")
    private WebElement resultBlock_instanceType;

    @FindBy(xpath = "//md-card-content[@id='resultBlock']//div[contains(text(), 'Region:')]")
    private WebElement resultBlock_region;

    @FindBy(xpath = "//md-card-content[@id='resultBlock']//div[contains(text(), 'Local SSD:')]")
    private WebElement resultBlock_localSSD;

    @FindBy(xpath = "//md-card-content[@id='resultBlock']//div[contains(text(), 'Commitment term:')]")
    private WebElement resultBlock_commitmentTerm;


    @FindBy(xpath = "//md-card-content[@id='resultBlock']//div[contains(text(), 'Instance type:')]/following-sibling::div[contains(text(), 'USD')]")
    private WebElement instanceCost;
    @FindBy(xpath = "//md-card-content[@id='resultBlock']//div[contains(text(), 'Local SSD:')]/following-sibling::div[contains(text(), 'USD')]")
    private WebElement localSSDCost;

    @FindBy(xpath = "//div[@class='cpc-cart-total']//b[contains(normalize-space(text()), 'Total Estimated Cost:')]")
    private WebElement resultBlock_totalCost;

    @FindBy(xpath = "//button[@id='Email Estimate']/span")
    private WebElement emailEstimateButton;

    @FindBy(xpath = "//md-input-container//input[@type='email']")
    private WebElement emailPopupField;

    @FindBy(xpath = "//button[(contains (text(), 'Send Email'))]")
    private WebElement sendEmailPopupButton;

    @FindBy(xpath = "//*[@id='cloud-site']/devsite-iframe/iframe")
    private WebElement iframe1;

    @FindBy(xpath = "//iframe[@id='myFrame']")
    private WebElement iframe2;

    public String provisioningModel, instanceType, region, localSSD, commitmentTerm, totalEstimatedCostString;
    public double totalCost, instCost, locSSDCost, componentsCostSum;

    public void getEquipmentResults() {
        provisioningModel = resultBlock_provisioningModel.getText();
        System.out.println(provisioningModel);
        instanceType = resultBlock_instanceType.getText();
        System.out.println(instanceType);
        region = resultBlock_region.getText();
        System.out.println(region);
        localSSD = resultBlock_localSSD.getText();
        System.out.println(localSSD);
        commitmentTerm = resultBlock_commitmentTerm.getText();
        System.out.println(commitmentTerm);
    }

    public void getPricesOfComponentsAndTotalCost(){
        System.out.println(instanceCost.getText());
        System.out.println(localSSDCost.getText());
        totalEstimatedCostString = resultBlock_totalCost.getText();
        System.out.println(totalEstimatedCostString);
        //System.out.println(resultBlock_totalCost.getAttribute("textContent"));
        totalEstimatedCostString = totalEstimatedCostString.split("Cost: USD ")[1];
        totalEstimatedCostString = totalEstimatedCostString.split(" per")[0];
        totalEstimatedCostString = totalEstimatedCostString.replaceAll("[^0-9.]", "");
        totalCost = Double.parseDouble(totalEstimatedCostString);
        System.out.println("Value of total cost: " + totalCost);

        instCost = Double.parseDouble(instanceCost.getText().replaceAll("[^0-9.]", ""));
        locSSDCost = Double.parseDouble(localSSDCost.getText().replaceAll("[^0-9.]", ""));
        componentsCostSum = instCost + locSSDCost;
        System.out.println("Estimated Component Cost: " + instCost + " + " + locSSDCost + " = " + componentsCostSum);
    }

    public void sendEmailWithPrice() throws InterruptedException {
        driver.switchTo().frame(iframe1);
        driver.switchTo().frame(iframe2);
        emailEstimateButton.click();
        explicitWait.until(ExpectedConditions.visibilityOf(emailPopupField)).click();
        Thread.sleep(2000);
        emailPopupField.sendKeys(Keys.CONTROL + "v");
        emailPopupField.sendKeys(Keys.ENTER);
        sendEmailPopupButton.click();
    }

    public void highlightPrices(){
        JavaScriptMethods.elementsHighlighter(instanceCost);
        JavaScriptMethods.elementsHighlighter(localSSDCost);
        JavaScriptMethods.elementsHighlighter(resultBlock_totalCost);
    }
}
