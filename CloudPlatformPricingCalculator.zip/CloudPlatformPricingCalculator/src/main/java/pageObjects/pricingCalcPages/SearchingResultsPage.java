package pageObjects.pricingCalcPages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import pageObjects.PageObjectBasics;

import java.util.List;

public class SearchingResultsPage extends PageObjectBasics {
    @FindBy(xpath = "//div[@class='catalog-filter-bar-container']/input")
    private WebElement searchField;

    @FindBy(xpath = "//div[@class='gsc-webResult gsc-result']//div[@class='gsc-thumbnail-inside']//a")
    private List<WebElement> searchResults;
    public SearchingResultsPage(WebDriver driver) {
        super(driver);
    }

    public String getSearchFieldTextContent(){
        return searchField.getAttribute("value");
    }

    public void choosingNeededSearchResult(String searchContent){
        System.out.println("Number of search results: " +searchResults.size());
        for(int i=0; i< searchResults.size(); i++){
            System.out.println(searchResults.get(i).getAttribute("textContent"));
            System.out.println(searchResults.get(i).getAttribute("textContent").equalsIgnoreCase(searchContent));

           if(searchResults.get(i).getAttribute("textContent").equalsIgnoreCase(searchContent)) {
               searchResults.get(i).click();
               break;
           }
        }
    }
}
