import org.openqa.selenium.*;

import org.testng.Assert;
import org.testng.annotations.*;
import pageObjects.pricingCalcPages.PricingCalculatorPage;
import testDataAndListeners.TestListener;
import utils.JavaScriptMethods;
import utils.WebDriverSingleton;


@Listeners(TestListener.class)

public class SimpleFailedTestScenario {
    protected static WebDriver driver;
    protected static PricingCalculatorPage pricingCalculatorPage;

    @BeforeClass(enabled = true)
    public static void startActions() {
        driver = WebDriverSingleton.getWebDriver();
        driver.get("https://cloud.google.com/products/calculator/");
    }

    @Test(description = "Simple test scenario with various variants of web page scrolling and trying of clicking on an element", priority = 1)
    public static void failedTest() throws InterruptedException {
        pricingCalculatorPage = new PricingCalculatorPage(driver);
        WebElement footerSolutions = driver.findElement(By.xpath("//*[@id='gc-wrapper']/devsite-footer-linkboxes/nav/ul/li[3]/h3"));
        Assert.assertEquals(driver.getTitle(), "Google Cloud Pricing Calculator");
        System.out.println(driver.getTitle());

        JavaScriptMethods.pageScroller();
        JavaScriptMethods.scrollToElement(footerSolutions);


        pricingCalculatorPage.calculatePrice();
    }

    @AfterTest(enabled = false)
    public static void endOfSession() {
        WebDriverSingleton.quitDriver();
    }
}
