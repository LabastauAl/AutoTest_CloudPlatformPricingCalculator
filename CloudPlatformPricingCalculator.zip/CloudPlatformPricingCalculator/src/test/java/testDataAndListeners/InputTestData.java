package testDataAndListeners;

public class InputTestData {
    public static final String searchContent = "Google Cloud Platform Pricing Calculator";

    public static final String provisioningModel = "Regular";
    public static final String instanceType = "n1-standard-8";
    public static final String region = "Frankfurt";
    public static final String localSSD = "2x375 GiB";
    public static final String commitmentTerm = "1 Year";
}
