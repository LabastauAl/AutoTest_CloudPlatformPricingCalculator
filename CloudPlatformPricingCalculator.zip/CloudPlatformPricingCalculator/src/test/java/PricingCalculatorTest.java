import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WindowType;
import org.testng.Assert;
import org.testng.annotations.*;
import pageObjects.emailServicePages.IncomingEmailsPage;
import pageObjects.emailServicePages.YopmailStartPage;
import pageObjects.pricingCalcPages.EstimateSubPage;
import pageObjects.pricingCalcPages.PricingCalculatorPage;
import pageObjects.pricingCalcPages.SearchingResultsPage;
import pageObjects.pricingCalcPages.StartPage;
import testDataAndListeners.InputTestData;
import testDataAndListeners.TestListener;
import utils.ScreenshotMaker;
import utils.WebDriverSingleton;

@Listeners(TestListener.class)

public class PricingCalculatorTest {
    protected static WebDriver driver;
    protected static StartPage startPage;
    protected static SearchingResultsPage searchingResultsPage;
    protected static PricingCalculatorPage pricingCalculatorPage;
    protected static EstimateSubPage estimateSubPage;
    protected static YopmailStartPage yopmailStartPage;
    protected static String initialBrowserWindow, secondBrowserWindow;
    protected static IncomingEmailsPage incomingEmailsPage;

    @BeforeClass(enabled = true)
    public static void startActions() {
        driver = WebDriverSingleton.getWebDriver();
        driver.get("https://cloud.google.com/");
        initialBrowserWindow = driver.getWindowHandle();
    }

    @Test(description = "Validate start_page title and entering required content to search in search filed", priority = 1)
    public static void enterSearchData() {
        startPage = new StartPage(driver);
        Assert.assertEquals(driver.getTitle(), "Cloud Computing Services  |  Google Cloud");
        startPage.searchingOfInfo(InputTestData.searchContent);
    }

    @Test(description = "Checking search_results_page title for consisting of search query. Go to the page with needed search result", priority = 2)
    public static void choosingSearchResult() throws InterruptedException {
        searchingResultsPage = new SearchingResultsPage(driver);
        Thread.sleep(2000);
        System.out.println(driver.getTitle());
        Assert.assertEquals(driver.getTitle().contains(InputTestData.searchContent),
                searchingResultsPage.getSearchFieldTextContent().contains(InputTestData.searchContent));
        searchingResultsPage.choosingNeededSearchResult(InputTestData.searchContent);
    }

    @Test(description = "Setting from drop-down lists the required configuration of equipment and calculation of its cost", priority = 3)
    public static void calculatePrice() {
        pricingCalculatorPage = new PricingCalculatorPage(driver);

        pricingCalculatorPage.pressComputeEngineButton();
        pricingCalculatorPage.calculatePrice();
    }

    @Test(description = "Validation of equipment parameters from generated result cost table", priority = 4)
    public static void checkEquipmentResultAndCost() {
        estimateSubPage = new EstimateSubPage(driver);
        boolean assertTrue;
        estimateSubPage.getEquipmentResults();

        Assert.assertTrue(estimateSubPage.provisioningModel.contains(InputTestData.provisioningModel));
//        assertTrue = estimateSubPage.provisioningModel.contains(InputTestDataAndConstants.provisioningModel);
//        System.out.println(assertTrue);

        Assert.assertTrue(estimateSubPage.instanceType.contains(InputTestData.instanceType));
//        assertTrue = estimateSubPage.instanceType.contains(InputTestDataAndConstants.instanceType);
//        System.out.println(assertTrue);

        Assert.assertTrue(estimateSubPage.region.contains(InputTestData.region));
//        assertTrue = estimateSubPage.region.contains(InputTestDataAndConstants.region);
//        System.out.println(assertTrue);

        Assert.assertTrue(estimateSubPage.localSSD.contains(InputTestData.localSSD));
//        assertTrue = estimateSubPage.localSSD.contains(InputTestDataAndConstants.localSSD);
//        System.out.println(assertTrue);

        Assert.assertTrue(estimateSubPage.commitmentTerm.contains(InputTestData.commitmentTerm));
//        assertTrue = estimateSubPage.commitmentTerm.contains(InputTestDataAndConstants.commitmentTerm);
//        System.out.println(assertTrue);
    }

    @Test(description = "Summing of components prices and validation with total estimated cost", priority = 5)
    public static void checkPricesAndResultCost() throws InterruptedException {
        estimateSubPage.getPricesOfComponentsAndTotalCost();
        Assert.assertEquals(estimateSubPage.totalCost, estimateSubPage.componentsCostSum);
        estimateSubPage.highlightPrices();
        Thread.sleep(1500);
        ScreenshotMaker.screenCaptureDuringTest(driver);
    }

    @Test(description = "Open temporary_email service in new tab and generate new email address", priority = 6)
    public static void getEmailAddress(){
        yopmailStartPage = new YopmailStartPage(driver);
        driver.switchTo().newWindow(WindowType.TAB);
        driver.get("https://yopmail.com/");
        Assert.assertTrue(driver.getTitle().contains("YOPmail"));
        secondBrowserWindow = driver.getWindowHandle();
        yopmailStartPage.generateNewEmail();
    }

    @Test(description = "Send email from result cost table and verify correctness of total estimated cost in received email", priority = 7)
    public static void sendEmailAndValidatePrice() throws InterruptedException {
        incomingEmailsPage = new IncomingEmailsPage(driver);
        driver.switchTo().window(initialBrowserWindow);
        estimateSubPage.sendEmailWithPrice();
        Thread.sleep(3000);
        driver.switchTo().window(secondBrowserWindow);
        Thread.sleep(3000);
        driver.navigate().refresh();
        yopmailStartPage.goToEmailPage();
        incomingEmailsPage.getPriceFromEmail();
        Assert.assertEquals(incomingEmailsPage.receivedPrice, estimateSubPage.totalCost);
    }

    @AfterTest
    public static void endOfSession() throws InterruptedException {
        Thread.sleep(3000);
        WebDriverSingleton.quitDriver();
    }
}
